<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id'])) {

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['full_name']) && $_SESSION['role'] == 'admin') {
	include "../DB_connection.php";

    function validate_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	$username = validate_input($_POST['username']);
	$password = validate_input($_POST['password']);
	$full_name = validate_input($_POST['full_name']);
	$id = validate_input($_POST['id']);


	if (empty($username)) {
		$errormsg = "Username is required";
	    header("Location: ../edit-user.php?error=$errormsg&id=$id");
	    exit();
	}else if (empty($password)) {
		$errormsg= "Password is required";
	    header("Location: ../edit-user.php?error=$errormsg&id=$id");
	    exit();
	}else if (empty($full_name)) {
		$errormsg = "Full name is required";
	    header("Location: ../edit-user.php?error=$errormsg&id=$id");
	    exit();
	}else {
    
       include "Model/User.php";
       $password = password_hash($password, PASSWORD_DEFAULT);

       $data = array($full_name, $username, $password, "employee", $id, "employee");
       update_user($conn, $data);

       $successmsg = "User created successfully";
	    header("Location: ../edit-user.php?success=$successmsg&id=$id");
	    exit();

    
	}
}else {
   $errormsg = "Unknown error occurred";
   header("Location: ../edit-user.php?error=$errormsg");
   exit();
}

}else{ 
   $errormsg= "First login";
   header("Location: ../edit-user.php?error=$errormsg");
   exit();
}