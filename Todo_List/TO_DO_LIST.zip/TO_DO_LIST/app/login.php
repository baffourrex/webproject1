<?php
session_start();
if (isset($_POST['username']) && isset($_POST['password'])){
    include "../DB_connection.php";

      function  validate_input($data){
        $data = trim($data);
        $data = stripcslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $username = validate_input($_POST['username']);
    $password = validate_input($_POST['password']);

    if (empty($username)){
        $errormsg = "username is required";
        header("Location: ../login.php?error=$errormsg");
        exit();
    } else if (empty($password)){
        $errormsg = "Password is required";
        header("Location: ../login.php?error=$errormsg");
        exit();
    }else{
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$username]);

        if ($stmt ->rowCount() == 1){
            $user = $stmt->fetch();
            $usernameDb = $user['username'];
            $passwordDb = $user['password'];
            $role = $user['role']; 
            $id = $user['id'];

            if($usernameDb === $usernameDb){
                if (password_verify($password,$passwordDb)){
                    if ($role == "admin"){
                       $_SESSION['role'] = $role;
                       $_SESSION['id'] = $id;
                       $_SESSION['username'] = $usernameDb;
                       header("Location: ../index.php?");

                    }elseif($role =='employee'){
                        $_SESSION['role'] = $role;
                        $_SESSION['id'] = $id;
                        $_SESSION['username'] = $usernameDb;
                        header("Location: ../index.php?");
                    }else{
                        $errormsg = "Incorrect username or Pasword";
                        header("Location: ../login.php?error=$errormsg");
                        exit();
                    }
                }else{
                    $errormsg = "Incorrect username or Pasword";
                    header("Location: ../login.php?error=$errormsg");
                    exit();
                }
            }else{
                $errormsg = "Incorrect username or Pasword";
                header("Location: ../login.php?error=$errormsg");
                exit();
            }
        }

    }


}else{
    $errormsg = "unknown error occured";
    header("Location: ../login.php?error=$errormsg");
    exit();
}
